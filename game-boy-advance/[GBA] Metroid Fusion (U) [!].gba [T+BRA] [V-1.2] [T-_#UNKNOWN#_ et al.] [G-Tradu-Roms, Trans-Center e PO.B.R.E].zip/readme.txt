Jogo: Metroid Fusion
Vers�o: Americana
Console: Gameboy Advance
Ano da tradu��o: 2008
Grupos de tradu��o: PO.B.R.E, Tradu-Roms e Trans-Center

---------------------NOTAS-------------------

Esse patch s� funcionar� na vers�o AMERICANA da rom. Caso aplique na vers�o Europ�ia, Japonesa, Coreana ou qualquer outra, a rom n�o funcionar� e ainda por cima estar� inutiliz�vel. Para precau��o, tenha em m�os a vers�o correta, e sempre fa�a uma c�pia de backup para precau��o.

Al�m disso, usem apenas roms sem intros. Ou seja, sem aquelas intros/splash screens feitas pelos grupos que riparam a rom. Caso use uma rom com intro, n�o garanto 100% de funcionamento da tradu��o.

----------LINHA DE HIST�RIA DO JOGO----------

Alguns anos depois da destrui��o de Zebes, Samus estava trabalhando para a Federa��o Gal�ctica como de costume. Ela havia recebido uma ordem para escoltar cientistas que iriam ao planeta SR388 fazer estudos sobre seu habitat e ecossistema atual. Ainda mais ap�s um bom tempo desde a extin��o dos Metr�ides que viviam l�, pois com isso eles supuseram que o planeta mudaria bastante.

Metr�ides eram seres dominantes em SR388, sua terra natal. Quaisquer outras esp�cies que viviam l�, eram suas presas. Foram criados pelos Chozo, uma civiliza��o de homens-p�ssaros com tecnologia sem igual, que viviam em v�rios planetas, incluindo Zebes e SR388. Foram os Chozo que acolheram Samus ap�s perder seus pais num ataque de Piratas Espaciais, quando ainda era beb�.

Ao chegar em SR388, Samus mata um dos esp�cimes para levar para estudo. Ap�s faz�-lo com um m�ssil, estranhamente de dentro do corpo arrebatado dessa esp�cie, sai uma ameba amarela flutuante. Samus tenta atingir essa ameba estranha, mas esta se esquiva e entra dentro do organismo da Samus.

Embora ela tenha estranhado a princ�pio, deixou essa preocupa��o de lado. Sem saber da pr�pria condi��o atual no momento, ela estava indo aos bio-laborat�rios onde levaram as amostras de SR388. At� que, no meio da viagem, ela perdeu a consci�ncia inesperadamente, e sua nave mergulhou de cabe�a num cintur�o de aster�ides.

No �ltimo instante, ela foi ejetada da nave gra�as aos sistemas de seguran�a. Imediatamente foi levada ao Quartel-General da Federa��o Gal�ctica, onde foi tratada por m�dicos. A causa da inesperada perda de consci�ncia da Samus foi a ameba flutuante que havia encontrado em SR388. Essa ameba foi nomeada de "X".

O X � uma esp�cie de parasita similar a um v�rus em v�rios aspectos. Eles invadem as v�timas, tornando-as suas hospedeiras. Ao invadir, copia o DNA de seu hospedeiro para si, reproduz-se rapidamente dentro dele, e a seguir o mata. Al�m disso, com base no DNA copiado, s�o capazes de imitar perfeitamente a v�tima, tanto em apar�ncia como em for�a e intelig�ncia. Os �nicos seres que os X n�o eram capazes de invadir e se hospedar, eram os Metr�ides j� extintos. Os X eram presas dos Metr�ides, dominantes em SR388. Quando os Chozo estiveram em SR388, perceberam o potencial destrutivo que os X representavam, e para aniquil�-los, criou os Metr�ides especificamente com este fim.

Samus estava em um estado s�rio devido a infec��o do X que sofreu em SR388. Numa tentativa de livr�-la dos X, cientistas removeram cirurgicamenta in�meras partes do seu Traje de For�a, mas ainda n�o foi o bastante. Os X estavam t�o fundidos ao sistema nervoso de Samus, que remover os X de dentro dela era arriscado demais. As chances de sobreviv�ncia dela eram m�nimas.

Mas, a sorte dela foi que algu�m havia encontrado uma cultura bacteriana com base em c�lulas do �ltimo Metr�ide de SR388 que Samus havia poupado a vida. A Federa��o havia preservado c�lulas deste Metr�ide antes dele morrer. Com base nessas c�lular, criaram a Vacina Metr�ide, e imediatamente a injetaram na Samus. Gra�as a esta vacina, todos os X que residiam dentro do corpo dela foram mortos rapidamente.

Samus havia sobrevivido, embora tenha perdido todas as suas habilidades de antes. Mas o pesadelo apenas come�ava. Durante a cirurgia, houve uma explos�o misteriosa nos bio-laborat�rios onde foram levadas as amostras de SR388. Samus foi enviada at� l� para investigar, sob a tutela de um Oficial de Comando computadorizado. Mal sabe ela que isto apenas � o prel�dio de cat�strofes que n�o envolver�o somente os bio-laborat�rios, como tamb�m SR388 e todo o universo...

---------------SOBRE A TRADU��O--------------

Em meados da �poca que a tradu��o do Metroid Zero Mission estava conclu�da e prestes a ser lan�ada, eu estava com planos de iniciar uma tradu��o do Metroid Fusion. Como as roms s�o bastante parecidas, deduzia que seria bem pr�tico e sem estresse dar cabo da parte de romhacking desse jogo. E realmente isso foi verdade.

No come�o, apenas brincava com a parte gr�fica e alguns mapas de tiles e de OAMs. A maioria esmagadora dos gr�ficos est� comprimida em LZ pra variar, pois � o formato de compress�o mais usado em GBA. A mesma f�rmula usada no Zero Mission foi usada no Fusion. A�, n�o haveria muitos problemas com isso.

Logo cedo, joapeer que havia se empolgado ao jogar o Zero Mission, jogou o Fusion e se empolgou mais ainda. Ele ent�o prop�s uma parceria para auxiliar na tradu��o e dar cabo da parte gr�fica. Come�ou colocando o alfabeto do Zero Mission no Fusion, que acabou combinando bem mais com o enredo hi-tech do jogo, � menor e cabe mais letras por linha. Alterou at� o comprimento VWF das letras. No fim ele ficou com a maior parcela da parte gr�fica do jogo.

Com isso, acabou sendo um projeto gra�as a uma parceria da Trans-Center e o PO.B.R.E.. Gra�as ao joapeer, a parte gr�fica rapidamente andou at� o fim. E posteriormente, peguei o MetroID criado pelo Odin e adaptei o c�digo, que s� funcionava no Metroid Zero Mission, para rodar no Fusion. Foi um pouco trabalhoso, mas no fim deu certo e com isso a parte textual passou a andar com gosto de g�s. Igualmente como no Zero Mission, o Darkl0rd se prop�s para revisar o Fusion tamb�m. Como ele � um �timo revisor e fez um �timo trabalho antes, certamente far� o mesmo agora.

Uns dias depois, falei com o Unknown, ex-romhacker da Tradu-Roms, j� inativa. Como ele j� havia traduzido esse jogo no passado, e fez um trabalho bom, decidi prop�r uma parceria com ele, de modo a usar a tradu��o dele como base em alguns aspectos, para assim traduzir mais r�pido e ainda unificar as coisas. Ele aceitou, e com isso o projeto acabou tendo o envolvimento de tr�s grupos, mesmo indiretamente: Tradu-Roms, PO.B.R.E. e Trans-Center.

A julgar pelo ponto que chegou, esse projeto acabou sendo meio que uma retradu��o, por�m deixando-a bem mais conclu�da e totalmente modificada. Na vers�o antiga dele, os gr�ficos n�o puderam ser editados ainda, gra�as � compress�o. Alguns poucos textos n�o foram traduzidos e alguns trechos da tradu��o dele poderiam ter ficado melhores. Tudo isso foi consertado e alterado de acordo.

De qualquer modo, basta de conversa. Usufruam do privil�gio, macacada! \o/

--------------STATUS DA TRADU��O-------------

Textos: 100%
Acentos: 100%
Gr�ficos: 100%

----------------AGRADECIMENTOS---------------

-Joapeer, pela maior parcela da edi��o gr�fica;
-Darkl0rd e Arara, pela revis�o;
-Odin, pelo MetroID, programa que modifiquei para funcionar no Fusion;
-Unknown, pela tradu��o inicial;
-Gambas, Anonymous_rs, Sonic_Spin e Kmikz, por ajudar Unknown na tradu��o inicial;
-todo o pessoal do PO.B.R.E., da Tradu-Roms e da Trans-center pelo apoio e ajuda na tradu��o.
	
-------------------HIST�RIA------------------

Vers�o 1.2 - 28/07/08
 Terceiro lan�amento. Vers�o Americana
 - Edi��o de 100% dos textos
 - Edi��o de 100% dos gr�ficos da rom que antes estavam comprimidos
 - Modifica��o e retradu��o de in�meros detalhes
 - In�meras melhorias gr�ficas

Vers�o 1.1 - 28/11/04
 Segundo lan�amento. Vers�o Americana
 - Corre��o no endere�o do site e outras coisas.

Vers�o 1.0 - 21/11/04
 Primeiro lan�amento. Vers�o Americana

-------------------COR�COR�------------------

Se voc� encontrou algum erro ortogr�fico, de concord�ncia ou algo parecido, por favor relate a mim por e-mail ou por MSN. Voc� encontra meu MSN no topo do arquivo.