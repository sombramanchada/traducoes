Aplicar na Rom: Tetris (JUE) (V1.1) [!].gb
Sistema: Game Boy
Genero: Puzzle
Produtora: Nintendo
Ano de Lan�amento: 1989
N� de Jogadores: 2
Tradutor: GuilhermeD2
Grupo: Tradu-Roms
Lan�amento da Tradu��o: 21/04/2000
Site: http://traduroms.cjb.net/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma