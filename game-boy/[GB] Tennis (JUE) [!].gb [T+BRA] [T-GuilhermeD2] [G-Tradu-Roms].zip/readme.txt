Aplicar na Rom: Tennis (JUE) [!].gb
Sistema: Game Boy
Genero: Espostes
Produtora: Nintendo
Ano de Lan�amento: 1989
N� de Jogadores: 2
Tradutor: GuilhermeD2
Grupo: Tradu-Roms
Lan�amento da Tradu��o: 2000
Site: http://traduroms.cjb.net/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma