Aplicar na Rom: Garfield Labyrinth (U).gb
Sistema: Game Boy
Genero: A��o
Produtora: Kemco
Ano de Lan�amento: 1993
N� de Jogadores: 1
Tradutor: Paulo GCS
Grupo: GB Man�acos
Lan�amento da Tradu��o: 29/12/2000
Site: http://www.gbmaniacos.com/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma