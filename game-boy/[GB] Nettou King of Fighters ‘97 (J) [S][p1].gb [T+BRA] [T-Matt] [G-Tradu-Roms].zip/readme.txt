Aplicar na Rom: Nettou King of Fighters ‘97 (J) [S][p1].gb
Sistema: Game Boy
Genero: Ação
Produtora: Takara
Ano de Lançamento: 1997
Nº de Jogadores: 2
Tradutor: Matt
Lançamento da Tradução: 19/07/2000 (provavelmente)
Traduzido: ???

Antes de aplicar o IPS na sua rom faça uma cópia da mesma
