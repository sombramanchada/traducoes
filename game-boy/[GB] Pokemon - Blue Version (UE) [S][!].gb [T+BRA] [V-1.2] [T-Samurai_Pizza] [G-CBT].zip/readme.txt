Aplicar na Rom: Pokemon - Blue Version (UE) [S][!].gb
Sistema: Game Boy
Genero: RPG
Produtora: Nintendo
Ano de Lan�amento: 1998
N� de Jogadores: 1
Tradutor: Samurai Pizza
Grupo: CBT
Lan�amento da Tradu��o: 26/11/1999
Site: http://www.emucamp.com/CBT/
Vers�o: 1.2
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma