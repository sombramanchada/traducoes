---------------------- Informa��es ----------------------

Nome do jogo original: Snoopy - Magic Show.
Nome no jogo: Snoopy e sua Turma.
Plataforma: Game Boy.
G�nero: Puzzle.
Distribuidora: Kemco.
Vers�o da Rom: Americana (U).
CRC32: 2B7A5034.
Lan�amento do Patch 1.0: 20 de Mar�o de 2009.
Site: http://monkeystraducoes.com/modules/news/
Link da Wiki: Nenhum.
Respons�vel: Wolfwood.
Grupo de Tradu��o: Monkey's Tradu��es.
E-mail: ikkidefenixalemao_@hotmail.com

---------------------- Como inserir o arquivo IPS na ROM original ----------------------
Itens:
- O arquivo .exe que veio junto com este arquivo.
- ROM Original.
***************************************
O que fazer:
*Abra o arquivo .exe.
*V� em Browse.
*Selecione a ROM Original.

Pronto! o seu jogo vai estar traduzido.
Para jog�-lo, basta ter o Emulador de Game Boy.

---------------------- Coment�rios ----------------------

N�o h� muito o que comentar. Achei esse jogo por a�, joguei e resolvi traduz�-lo. Foi o jogo mais f�cil que j� ownei em toda a minha vida, d� para criar um hack f�cil desse jogo, tem uma tool dele no Romhacking.net, que eu n�o usei. =D

Todos os gr�ficos que se tinha para editar foram editados, o mesmo aconteceu com os textos, se tiver mais textos eu n�o os encontrei. Se algu�m encontrar algo n�o traduzido, favor entrar em contato.  8)

O t�tulo original �: "Snoopy - Magic Show."; eu resolvi mudar o t�tulo para "Snoopy e sua Turma" justamente por combinar mais do que "Magic Show", porque n�o tem nada de m�gica no jogo! Pelo menos eu n�o encontrei nada. Esse foi o melhor t�tulo que me veio em mente.

---------------------- Agradecimentos ----------------------

*Minha m�e - COEH! Sem ela eu n�o estaria aqui, entregando essa tradu��o para voc�s. XD
*Minha ex - Ah... fuck you. Eu gosto dela, e dai?
*Heero Yui - Por ter deixado eu traduzir esse jogo.
*Sonic Away - Melhoras!
E todos aqueles que esperaram ansiosamente pela tradu��o.