Aplicar na Rom: Double Dragon 2 (U) [!].gb
Sistema: Game Boy
Genero: Luta
Produtora: Technos
Ano de Lan�amento: 1991
N� de Jogadores: 2
Tradutor: Ericus_Travis
Grupo: Evil Darkness
Lan�amento da Tradu��o: 16/06/2002
Site: http://membres.lycos.fr/edromhack/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma