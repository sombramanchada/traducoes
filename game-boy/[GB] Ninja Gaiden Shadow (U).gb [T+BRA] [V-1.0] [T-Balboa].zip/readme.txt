Aplicar na Rom: Ninja Gaiden Shadow (U).gb
Sistema: Game Boy
Genero: A��o/Plataforma
Produtora: Tecmo
Ano de Lan�amento: 1991
N� de Jogadores: 1
Tradutor: Balboa
Grupo: Nenhum
Lan�amento da Tradu��o: 04/11/2007
Site: Nenhum
Vers�o: 1.0
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma