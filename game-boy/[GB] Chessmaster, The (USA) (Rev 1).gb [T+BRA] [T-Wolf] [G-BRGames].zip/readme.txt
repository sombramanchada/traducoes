Aplicar na Rom: The Chessmaster (UE) (V1.1) [!].gb
Sistema: Game Boy
Genero: Estrat�gia
Produtora: Park Place
Ano de Lan�amento: 1990
N� de Jogadores: 1
Tradutor: Wolf
Grupo: BR Games
Lan�amento da Tradu��o: 27/05/2001
Site: http://www.brgames.org/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma