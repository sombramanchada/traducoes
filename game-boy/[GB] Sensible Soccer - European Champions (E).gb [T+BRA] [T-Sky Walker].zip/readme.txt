Aplicar na Rom: Sensible Soccer (U) [b1].gb
Sistema: Game Boy
Genero: Esportes
Produtora: Sensible Software
Ano de Lan�amento: 1993
N� de Jogadores: 1
Tradutor: Sky Walker
Grupo: BR Games
Lan�amento da Tradu��o: 04/03/2000
Site: http://www.brgames.org/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma