﻿Castlevânia: A Aventura (Castlevania: The Adventure / ドラキュラ伝説)
Plataforma: GameBoy
Ano: 1989
Sinopse: Drácula desperta de seu sono centenário, com a certeza de que seu plano funcionou e que não há mais que temer a família Belmont. Ele estava enganado. Christopher Belmont o prova isto. Durante a batalha com Christopher, Drácula sente que o melhor a fazer é fugir. Ele não teve chances contra o Belmont, então decidiu esperar uma nova oportunidade para atacar, que ocorre quinze anos após o combate. (retirado da Wikipedia)

Castlevânia II: A Vingança dos Belmont (Castlevania II: Belmont's Revenge / ドラキュラ伝説 II)
Plataforma: GameBoy
Ano: 1991
Sinopse: Quinze anos depois, Drácula descobriu o filho de Christopher, Soleiyu. Ele raptou o jovem garoto e dominou sua mente, forçando Christopher a ser mais cuidadoso em sua segunda batalha. Após ser forçado a enfrentar e derrotar seu próprio filho, Christopher segue em fúria rumo ao Conde. (retirado da Wikipedia)

Tradução:
Tradutor: GANO
Versão: 1.0
Ano: 2006 / 2008
Email: sei_la0@yahoo.com.br
Sobre: Essas são duas traduções que eu fiz a algum tempo e nunca tive coragem de divulgar.
O que me motivou a tradução foi eu ter jogado o segundo no GB e gostado, como eu vi que o primeiro quase não tinha texto eu resolvi traduzi-lo também (na verdade os dois têm muito pouco texto :P).
São dois grandes clássicos de GameBoy e que carregam o nome da grande franquia Castlevania, uma das minha favoritas.
Os jogos têm dificuldade mediana (mais baixa que a maioria dos Castlevania's) os gráficos são fracos mas músicas são boas, ou seja, estes jogos são aconselhado para fãs da franquia ou quem gosta um Action de plataforma.

Erros e Problemas:
No segundo, eu não encontrei os textos "REST" e "SCORE" que aparecem quando o jogo é pausado.
Eu joguei a tradução do começo ao fim no VisualBoyAdvance e não encontrei nenhum problema. Também testei a tradução no Gest e no KiGB, mas não joguei até o fim e não sei se poderá dar algum problema neste ou em outros emuladores.
Caso você encontre algum erro ou bug, queira me informar pelo meu e-mail.
