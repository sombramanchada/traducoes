Aplicar na Rom: Bugs Bunny (U) [!].gb
Sistema: Game Boy
Genero: A��o
Produtora: Kemco
Ano de Lan�amento: 1990
N� de Jogadores: 1
Tradutor: Wolf
Grupo: Emuway
Lan�amento da Tradu��o: 2000
Site: http://www.emuway.f2s.com/
Vers�o: 1.0
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma