Aplicar na Rom: Mega Man (U).gb
Sistema: Game Boy
Genero: A��o/Plataforma
Produtora: Capcom
Ano de Lan�amento: 1991
N� de Jogadores: 1
Tradutor: Emuboarding
Grupo: EmuNow
Lan�amento da Tradu��o: 17/10/1999
Site: http://www.emunow.cjb.net/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma