Aplicar na Rom: Ninja Gaiden Shadow (U).gb
Sistema: Game Boy
Genero: A��o/Plataforma
Produtora: Tecmo
Ano de Lan�amento: 1991
N� de Jogadores: 1
Tradutor: Hellmatic
Grupo: Emula��o Brasil
Lan�amento da Tradu��o: 13/08/1997
Site: http://a_herrmann.sites.uol.com.br/emubr/
Vers�o: ???
Traduzido: 99%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma