Aplicar na Rom: Super Mario Land (JUE) (V1.1) [!].gb
Sistema: Game Boy
Genero: A��o/Plataforma
Produtora: Nintendo
Ano de Lan�amento: 1989
N� de Jogadores: 1
Tradutor: Jackal
Grupo: BR Games
Lan�amento da Tradu��o: 25/03/2000
Site: http://www.brgames.org/
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma