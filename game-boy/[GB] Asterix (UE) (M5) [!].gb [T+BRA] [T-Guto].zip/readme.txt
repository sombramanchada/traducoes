GUTO TRADU��ES >>>>>

Lan�amento: Asterix para Gameboy Mono.
Vers�o utilizada: (UE)
Porcentagem: 100%
Tradu��o finalizada em: xx-Mar�o-05
Tradu��o: Ingl�s -> Portugu�s (Brasil)
Tradutor: Guto

Por falta de espa�os, n�o foi poss�vel colocar os acentos, mas mesmo assim a tradu��o ficou muito boa!

-----------------------------------------------------------------------

Para aplicar a tradu��o, use o SNESTOOL! Ou ent�o utilize o seu aplicador de IPs preferido.
Ou o IPS-EXE que vem acompanhado basta clicar em "Browse" selecionar a ROM e depois clicar em "Patch".

-----------------------------------------------------------------------

Contato: gutosabenca@gmail.com
Website: http://www.gutotraducoes.cjb.net