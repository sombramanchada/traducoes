Aplicar na Rom: Real Bout Special (J) [S].gb
Sistema: Game Boy
Genero: Luta
Produtora: Takara
Ano de Lan�amento: 1998
N� de Jogadores: 2
Tradutor: Matt
Lan�amento da Tradu��o: 19/07/2000
Vers�o: ???
Traduzido: 100%

Antes de aplicar o IPS na sua rom fa�a uma c�pia da mesma
