----------------------------Hexagon Tradu��es--------------------------
                       
                       (http://hexagon.romhack.net)
                       
                       Grupo Brasileiro de Tradu��o
_______________________________________________________________________

                Jogo traduzido: Final Fantasy Legend II
                             Vers�o: 1.0
                          Console: Game Boy


====================
==SOBRE A TRADU��O==
====================
A tradu��o come�ou logo ap�s o lan�amento de Final Fantasy 2 de SNES.
Depois, adaptando algumas coisas usadas no FF2 e fazendo as altera��es
necess�rias, Final Fantasy Legend 2 estava pronto para ser traduzido
sem limita��es. Fiz essa tradu��o sozinho, desde a programa��o,
Romhack, at� a tradu��o dos textos. O �nico problema que aconteceu foi
o espa�o para os acentos, problema este que ocorrera no Final Fantasy 2
de SNES mas que fora solucionado. A solu��o, infelizmente, n�o era
aplic�vel ao FF Legend 2, devido a estrutura da ROM de GB ser
diferente da de SNES.
No final, tive que deixar a fonte toda em mai�sculo. Para ficar mais
"bonitinho", pus uma fonte nova.
Hmmm... Acho que n�o h� nada mais pra ser dito. Afinal, ser� que algu�m
de fato l� os textos que v�m com as tradu��es?

 - GreenGoblin


==========
==F.A.Q.==
==========
PERGUNTA): EH VERDAD Q SE A JENTE FOR A DECIMA TERCERA PESSOA A JOGAR
A TRADU NOIS GANHA UM DVD?!?!????
RESPOSTA): Apesar de uma promo��o dessas ser extremamente poss�vel de
realizarmos em virtude da grande quantia de dinheiro que ganhamos
traduzindo (pouco menos que nada), n�o, n�o � verdade.

PERGUNTA): Porra, Final Fantasy Legend... eu nem sabia que existia
isso. Qual�?
RESPOSTA): Existem quatro FFs para GameBoy. Final Fantasy Legend 1, 2,
3 e Final Fantasy Adventure. A s�rie Legend � conhecida tamb�m como
Sa-Ga no jap�o (que continua no SNES e depois PSX).

PERGUNTA): Posso colocar essa tradu��o no meu site?
RESPOSTA): Claro, desde que nos d� o devido cr�dito e coloque no seu
site exatamente o mesmo arquivo zipado.

PERGUNTA): PQ VC'Z COMESSARAN PELO 2?! COEH! VAUM TARDUZI OS OTRO
TABEN?!?!?1
RESPOSTA): Comecei pelo 2 porque eu quis. Se vamos traduzi os outros...
bem, talvez fa�amos se recebermos mais pedidos.

PERGUNTA): ONDE ENCONTRO UM TOTORIAL SOBRE O LOGARITMO DA COMPRESAO
USADA NO FANTASI ESTAR 4?!?!??////1/1///
RESPOSTA): Sei l�.


============
==CR�DITOS==
============
Tradu��o: GreenGoblin
Revis�o: GreenGoblin
Programa��o de utilit�rios: GreenGoblin
Acentua��o: GreenGoblin
Altera��es gr�ficas: GreenGoblin
Tabela/Tabela de DTEs: GreenGoblin
Altera��o de DTEs: GreenGoblin
Testes: GreenGoblin
Cafezinho: Shadows_Girl
Faxina: Iori-Yagami
Supervisor de Faxina: |Mestre-Yoda|


================================
==TERMOS DE USO E DISTRIBUI��O==
================================
N�o seremos respons�veis por qualquer dano causado pelo uso indevido
dos arquivos referentes a tradu��o de Final Fantasy Legend II.

Sobre a distribui��o, voc� tem a permiss�o para distribuir livremente
a tradu��o, desde que esse texto e o IPS sempre sejam inclusos
na distribui��o. Tamb�m pedimos para sempre darem o nosso devido
cr�dito pela tradu��o.
A venda desta tradu��o tamb�m � expressamente proibida, fazemos isso
gratuitamente e algu�m ganhar dinheiro em cima disto � inaceit�vel.



-----------------------------------------------------------------------
 Qualquer coment�rio a respeito da tradu��o deve ser enviado ao
e-mail da Hexagon (hexagonbr@hotmail.com) ou ao F�rum na p�gina
principal da Hexagon.