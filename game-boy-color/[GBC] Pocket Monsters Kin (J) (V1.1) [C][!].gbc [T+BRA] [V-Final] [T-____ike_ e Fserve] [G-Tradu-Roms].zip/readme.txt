Aplicar na Rom: Pocket Monsters Kin (J) (V1.0) [C][!].gbc ou Pocket Monsters Kin (J) (V1.1) [C][!].gbc
Sistema: Game Boy Color
Genero: RPG
Produtora: Game Freak
Ano de Lançamento: 1999
Nº de Jogadores: 1
Tradutor: ____ike_ e Fserve
Grupo: Tradu-Roms
Lançamento da Tradução: 2001
Site: http://www.traduroms.cjb.net
Traduzido: 75%

Antes de aplicar o IPS na sua rom faça uma cópia da mesma
