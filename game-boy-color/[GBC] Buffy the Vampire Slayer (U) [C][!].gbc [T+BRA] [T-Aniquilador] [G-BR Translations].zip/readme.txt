Aplicar na Rom: Buffy the Vampire Slayer (U) [C][!].gbc
Sistema: Game Boy Color
Genero: Beat 'Em Up
Produtora: THQ
Ano de Lançamento: 2000
Nº de Jogadores: 1
Tradutor: Aniquilador
Grupo: BR Translations
Lançamento da Tradução: 2001
Site: http://brtranslations.no.sapo.pt/
Traduzido: 100%

Antes de aplicar o IPS na sua rom faça uma cópia da mesma
